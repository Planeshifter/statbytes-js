var compute = require( 'compute.io' ),
  sepal = require( 'datasets-iris-setosa-sepal' ),
  d3 = require( 'd3' );
